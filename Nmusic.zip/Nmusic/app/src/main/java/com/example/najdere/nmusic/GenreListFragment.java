package com.example.najdere.nmusic;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import com.example.najdere.nmusic.R;
import com.example.najdere.nmusic.GenreAdapter;
import com.example.najdere.nmusic.GenreInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class GenreListFragment extends Fragment {


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.genrelist_libary, container, false);


        return rootView;
    }





}

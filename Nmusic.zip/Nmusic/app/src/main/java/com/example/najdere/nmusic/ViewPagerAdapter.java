package com.example.najdere.nmusic;

public class ViewPagerAdapter {
}

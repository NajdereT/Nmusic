package com.example.najdere.nmusic;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import com.example.najdere.nmusic.AlbumInfo;
import com.example.najdere.nmusic.R;
import com.example.najdere.nmusic.AlbumAdapter;
import com.wonderkiln.blurkit.BlurLayout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class AlbumListFragment extends Fragment {

    private RecyclerView albumrecycler;
    private GridView albumsgrid;
    private ArrayList<AlbumInfo> albumList;
    private BlurLayout blurLayout;


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.albumlist_libary, container, false);





        return rootView;



    }

}
